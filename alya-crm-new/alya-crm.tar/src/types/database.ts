// Tipos do banco de dados
export interface Perfil {
  id: string
  nome: string
  email: string
  telefone: string | null
  creci: string | null
  avatar_url: string | null
  plano: 'CORRETOR_SOLO' | 'EQUIPE' | 'IMOBILIARIA' | 'REDE' | 'ADMIN_MASTER'
  criado_em: string
  atualizado_em: string
}

export interface Lead {
  id: string
  usuario_id: string
  nome: string
  email: string | null
  telefone: string
  cpf: string | null
  rg: string | null
  data_nascimento: string | null
  profissao: string | null
  estado_civil: string | null
  renda_mensal: number | null
  origem: 'MANUAL' | 'SITE' | 'WHATSAPP' | 'FACEBOOK' | 'INSTAGRAM' | 'INDICACAO'
  orcamento_min: number | null
  orcamento_max: number | null
  preferencias: Record<string, any>
  observacoes: string | null
  criado_em: string
  atualizado_em: string
}

export interface Imovel {
  id: string
  usuario_id: string
  titulo: string
  tipo: 'APARTAMENTO' | 'CASA' | 'TERRENO' | 'COMERCIAL' | 'RURAL'
  endereco: string | null
  cidade: string | null
  estado: string | null
  cep: string | null
  valor: number
  area_m2: number | null
  quartos: number
  banheiros: number
  vagas: number
  condominio: number | null
  iptu: number | null
  descricao: string | null
  caracteristicas: string[]
  fotos: string[]
  status: 'DISPONIVEL' | 'RESERVADO' | 'VENDIDO'
  ativo: boolean
  criado_em: string
  atualizado_em: string
}

export type EtapaKanban = 
  | 'NOVO_LEAD'
  | 'PRIMEIRO_CONTATO'
  | 'APRESENTACAO'
  | 'VISITA_AGENDADA'
  | 'PROPOSTA_ENVIADA'
  | 'ANALISE_DOCUMENTACAO'
  | 'FECHAMENTO'

export type Prioridade = 'ALTA' | 'MEDIA' | 'BAIXA'

export interface Negociacao {
  id: string
  usuario_id: string
  lead_id: string
  imovel_id: string | null
  etapa: EtapaKanban
  prioridade: Prioridade
  valor_proposta: number | null
  data_proxima_acao: string | null
  observacoes: string | null
  criado_em: string
  atualizado_em: string
  // Relacionamentos
  lead?: Lead
  imovel?: Imovel
  atividades?: Atividade[]
}

export type TipoAtividade = 
  | 'LIGACAO'
  | 'EMAIL'
  | 'WHATSAPP'
  | 'VISITA'
  | 'REUNIAO'
  | 'PROPOSTA'
  | 'FOLLOW_UP'

export interface Atividade {
  id: string
  negociacao_id: string
  tipo: TipoAtividade
  descricao: string | null
  data_atividade: string
  concluida: boolean
  criado_em: string
}

// Database types para Supabase
export interface Database {
  public: {
    Tables: {
      perfis: {
        Row: Perfil
        Insert: Omit<Perfil, 'id' | 'criado_em' | 'atualizado_em'>
        Update: Partial<Omit<Perfil, 'id' | 'criado_em' | 'atualizado_em'>>
      }
      leads: {
        Row: Lead
        Insert: Omit<Lead, 'id' | 'criado_em' | 'atualizado_em'>
        Update: Partial<Omit<Lead, 'id' | 'criado_em' | 'atualizado_em'>>
      }
      imoveis: {
        Row: Imovel
        Insert: Omit<Imovel, 'id' | 'criado_em' | 'atualizado_em'>
        Update: Partial<Omit<Imovel, 'id' | 'criado_em' | 'atualizado_em'>>
      }
      negociacoes: {
        Row: Negociacao
        Insert: Omit<Negociacao, 'id' | 'criado_em' | 'atualizado_em'>
        Update: Partial<Omit<Negociacao, 'id' | 'criado_em' | 'atualizado_em'>>
      }
      atividades: {
        Row: Atividade
        Insert: Omit<Atividade, 'id' | 'criado_em'>
        Update: Partial<Omit<Atividade, 'id' | 'criado_em'>>
      }
    }
  }
}
